//
//  server.h
//  SkiPass
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>

#define PORT 8080
#define MAX_SKIPASS 100
#define BUFFER_SIZE 1024


typedef struct {
    char code[20];
    int valid;
} Skipass;

void initialize_skipasses(void);
int find_skipass(char *);
void *handle_client(void *);
