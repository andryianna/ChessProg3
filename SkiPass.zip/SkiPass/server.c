#include "server.h"


Skipass skipasses[MAX_SKIPASS];
int skipass_count = 0;
pthread_mutex_t skipass_mutex = PTHREAD_MUTEX_INITIALIZER;


void initialize_skipasses(void) {
    strcpy(skipasses[0].code, "ABC123"); skipasses[0].valid = 1;
    strcpy(skipasses[1].code, "DEF456"); skipasses[1].valid = 1;
    skipass_count = 2;
}

int find_skipass(char *code) {
    for (int i = 0; i < skipass_count; i++) {
        if (strcmp(skipasses[i].code, code) == 0) {
            return i;
        }
    }
    return -1;
}

int add_skipass(char *code) {
    if (skipass_count >= MAX_SKIPASS) return -1; // Limite massimo raggiunto
    if (find_skipass(code) != -1) return 0;      // Skipass già presente

    strcpy(skipasses[skipass_count].code, code);
    skipasses[skipass_count].valid = 1;
    skipass_count++;
    return 1;
}

int main(void) {
    int server_fd, new_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);

    initialize_skipasses();

    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }

    if (listen(server_fd, 3) < 0) {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }

    printf("Server listening on port %d...\n", PORT);

    while (1) {
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen)) < 0) {
            perror("Accept failed");
            continue;
        }

        pthread_t thread_id;
        int *client_socket = malloc(sizeof(int));
        *client_socket = new_socket;
        pthread_create(&thread_id, NULL, handle_client, (void*)client_socket);
    }

    return 0;
}

void *handle_client(void *arg) {
    int client_socket = *(int *)arg;
    free(arg);
    char buffer[BUFFER_SIZE];

    while (1) {
        memset(buffer, 0, BUFFER_SIZE);
        read(client_socket, buffer, BUFFER_SIZE);

        if (strncmp(buffer, "EXIT", 4) == 0) break;

        char *cmd = strtok(buffer, " ");
        char *code = strtok(NULL, " ");

        if (cmd && code) {
            pthread_mutex_lock(&skipass_mutex);
            int index = find_skipass(code);

            if (strcmp(cmd, "CHECK") == 0) {
                if (index != -1 && skipasses[index].valid) {
                    write(client_socket, "VALID\n", 6);
                } else {
                    write(client_socket, "INVALID\n", 8);
                }
            } else if (strcmp(cmd, "CANCEL") == 0) {
                if (index != -1) {
                    skipasses[index].valid = 0;
                    write(client_socket, "CANCELLED\n", 10);
                } else {
                    write(client_socket, "NOT FOUND\n", 10);
                }
            } else if (strcmp(cmd, "ADD") == 0) {
                int result = add_skipass(code);
                if (result == 1) {
                    write(client_socket, "ADDED\n", 6);
                } else if (result == 0) {
                    write(client_socket, "ALREADY EXISTS\n", 15);
                } else {
                    write(client_socket, "LIMIT REACHED\n", 14);
                }
            }
            pthread_mutex_unlock(&skipass_mutex);
        }
    }
    close(client_socket);
    return NULL;
}
